package com.example.ga

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
